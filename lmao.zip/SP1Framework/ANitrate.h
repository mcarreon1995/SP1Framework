#pragma once
#include "Entity.h"
class ANitrate :
    public Entity
{
private:
public:
	ANitrate();
	~ANitrate();
	char getName();
};


