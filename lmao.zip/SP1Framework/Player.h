#pragma once
#include "Entity.h"
class Player
{
public:
	Player();
	~Player();
	char getName();
};





