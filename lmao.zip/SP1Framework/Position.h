#pragma once
class Position
{
private:
	int x, y;

public:
	Position();
	~Position();

	void setXpos(int xPos);
	int getXpos();

	void setYpos(int Ypos);
	int getYpos();


};
