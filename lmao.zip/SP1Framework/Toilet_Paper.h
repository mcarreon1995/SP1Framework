#pragma once
#include "Entity.h"
class Toilet_Paper :public Entity
{
private:
public:
	Toilet_Paper();
	~Toilet_Paper();
	char getName();
};

