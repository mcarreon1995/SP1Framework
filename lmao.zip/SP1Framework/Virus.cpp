#include "Virus.h"
Virus::Virus() {

}

Virus::~Virus() {

}

char Virus::getName() {
	return 'V';
}

void Virus::move() {


}
