#include "Bat.h"
Bat::Bat() {

}

Bat::~Bat() {

}

char Bat::getName() {
	return 'B';
}

void Bat::move() {


}