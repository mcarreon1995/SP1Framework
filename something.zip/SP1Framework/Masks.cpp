#include "Masks.h"
Masks::Masks() {

}

Masks::~Masks() {

}

char Masks::getName() {
	return 'M';
}
