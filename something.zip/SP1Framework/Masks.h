#pragma once
#include "Entity.h"
class Masks :public Entity
{
public:
	Masks();
	~Masks();
	char getName();
};

