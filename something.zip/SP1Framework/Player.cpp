#include "Player.h"

Player::Player() {

}

Player::~Player() {

}

char Player::getName() {
	return 'P';
}