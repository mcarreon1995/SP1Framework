#include "ToiletPaper.h"
ToiletPaper::ToiletPaper() {

}

ToiletPaper::~ToiletPaper() {

}

char ToiletPaper::getName() {
	return 'F';
}