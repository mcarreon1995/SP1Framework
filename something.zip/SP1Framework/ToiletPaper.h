#pragma once
#include "Entity.h"
class ToiletPaper:public Entity
{
public:
	ToiletPaper();
	~ToiletPaper();
	char getName();
};


