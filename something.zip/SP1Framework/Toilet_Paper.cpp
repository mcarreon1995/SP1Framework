#include "Toilet_Paper.h"

Toilet_Paper::Toilet_Paper() {

}

Toilet_Paper::~Toilet_Paper() {

}

char Toilet_Paper::getName() {
	return 'T';
}

