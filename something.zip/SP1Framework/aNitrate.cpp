
#include "ANitrate.h"

ANitrate::ANitrate() {

}

ANitrate::~ANitrate() {

}

char ANitrate::getName() {
	return 'A';
}
